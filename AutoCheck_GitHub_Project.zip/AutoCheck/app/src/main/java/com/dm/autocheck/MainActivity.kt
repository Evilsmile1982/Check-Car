package com.dm.autocheck

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    companion object {
        private const val INTRO_DURATION = 2500L
    }

    private val red = Color.rgb(255, 23, 23)
    private val white = Color.WHITE
    private val panel = Color.argb(235, 12, 14, 18)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        setContentView(root)

        val background = ImageView(this).apply {
            setImageResource(R.drawable.home_background)
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.98f
        }
        root.addView(background, FrameLayout.LayoutParams(-1, -1))

        val header = createHeader()
        root.addView(header, headerParams())

        val menu = createMenu()
        root.addView(menu, menuParams())

        // Header enters from above, all three top buttons from the right,
        // all three bottom buttons from the left. Every movement takes 2.5s.
        root.post {
            header.translationY = -header.height.toFloat()
            header.animate()
                .translationY(0f)
                .setDuration(INTRO_DURATION)
                .start()

            val topRow = menu.getChildAt(0) as ViewGroup
            val bottomRow = menu.getChildAt(1) as ViewGroup
            val distance = root.width.toFloat() + dp(80)

            topRow.translationX = distance
            bottomRow.translationX = -distance

            topRow.animate().translationX(0f).setDuration(INTRO_DURATION).start()
            bottomRow.animate().translationX(0f).setDuration(INTRO_DURATION).start()
        }
    }

    private fun createHeader(): LinearLayout {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val gear = ImageView(this).apply {
            setImageResource(R.drawable.gear_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            // The cropped gear contains the same dark garage background, so it blends into the hero scene.
        }
        header.addView(gear, LinearLayout.LayoutParams(dp(105), dp(105)))

        val title = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        title.addView(styledTitle("AUTO", white))
        title.addView(styledTitle(" CHECK", red))
        header.addView(title, LinearLayout.LayoutParams(-2, dp(58)))

        val subtitle = TextView(this).apply {
            text = "VERLIERE NICHT DIE ÜBERSICHT"
            setTextColor(Color.WHITE)
            alpha = 0.92f
            textSize = 13f
            letterSpacing = 0.22f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        header.addView(subtitle, LinearLayout.LayoutParams(-2, dp(32)))

        val line = View(this).apply {
            setBackgroundColor(red)
            alpha = 0.9f
        }
        val lineParams = LinearLayout.LayoutParams(dp(260), dp(2)).apply {
            topMargin = dp(4)
        }
        header.addView(line, lineParams)

        return header
    }

    private fun styledTitle(text: String, color: Int): TextView = TextView(this).apply {
        this.text = text
        setTextColor(color)
        textSize = 34f
        typeface = Typeface.create("sans-serif-black", Typeface.BOLD_ITALIC)
        gravity = Gravity.CENTER
        setShadowLayer(12f, 0f, 0f, if (color == red) Color.RED else Color.WHITE)
    }

    private fun createMenu(): LinearLayout {
        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }

        val top = rowOf(
            MenuItem("MEIN AUTO", "🚗"),
            MenuItem("REPARATUREN", "🛠"),
            MenuItem("WARTUNGEN", "▣")
        )
        val bottom = rowOf(
            MenuItem("KOSTEN", "☷"),
            MenuItem("STATISTIK", "▥"),
            MenuItem("EINSTELLUNGEN", "⚙")
        )

        menu.addView(top)
        menu.addView(bottom)
        return menu
    }

    private data class MenuItem(val label: String, val icon: String)

    private fun rowOf(vararg items: MenuItem): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        items.forEachIndexed { index, item ->
            val button = createMenuButton(item, index == 0 && item.label == "MEIN AUTO")
            val p = LinearLayout.LayoutParams(0, dp(116), 1f).apply {
                marginStart = if (index == 0) 0 else dp(6)
                marginEnd = if (index == items.lastIndex) 0 else dp(6)
            }
            row.addView(button, p)
        }
        return row
    }

    private fun createMenuButton(item: MenuItem, selected: Boolean): TextView {
        val button = TextView(this).apply {
            isClickable = true
            isFocusable = true
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(8), dp(4), dp(8))
            text = "${item.icon}\n${item.label}"
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            letterSpacing = 0.04f
            background = buttonBackground(selected)
            stateListAnimator = null
            elevation = dp(6).toFloat()
            setOnClickListener {
                val intent = Intent(this@MainActivity, SubMenuActivity::class.java)
                intent.putExtra(SubMenuActivity.EXTRA_TITLE, item.label)
                startActivity(intent)
            }
            setOnTouchListener { v, event ->
                when (event.action) {
                    android.view.MotionEvent.ACTION_DOWN -> {
                        v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
                    }
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    }
                }
                false
            }
        }
        return button
    }

    private fun buttonBackground(selected: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(18).toFloat()
            setColor(panel)
            setStroke(dp(if (selected) 2 else 1), if (selected) red else Color.argb(160, 170, 175, 185))
        }
    }

    private fun headerParams(): FrameLayout.LayoutParams = FrameLayout.LayoutParams(-1, dp(225)).apply {
        gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        topMargin = dp(20)
        leftMargin = dp(18)
        rightMargin = dp(18)
    }

    private fun menuParams(): FrameLayout.LayoutParams = FrameLayout.LayoutParams(-1, dp(244)).apply {
        gravity = Gravity.BOTTOM
        leftMargin = dp(18)
        rightMargin = dp(18)
        bottomMargin = dp(24)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
}
