package com.dm.autocheck

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity

class SubMenuActivity : ComponentActivity() {
    companion object {
        const val EXTRA_TITLE = "title"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val title = intent.getStringExtra(EXTRA_TITLE) ?: "MENÜ"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(40), dp(24), dp(24))
            setBackgroundColor(Color.rgb(7, 8, 10))
        }

        val heading = TextView(this).apply {
            text = title
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD_ITALIC)
            gravity = Gravity.CENTER
        }
        root.addView(heading, LinearLayout.LayoutParams(-1, dp(70)))

        val info = TextView(this).apply {
            text = "Untermenü für $title\n\nHier können als nächstes Fahrzeugdaten, Termine, Kosten, Reparaturen oder Einstellungen ergänzt werden."
            textSize = 17f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(info, LinearLayout.LayoutParams(-1, 0, 1f))

        val back = Button(this).apply {
            text = "ZURÜCK"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(190, 0, 0))
            setOnClickListener { finish() }
        }
        root.addView(back, LinearLayout.LayoutParams(-1, dp(56)))

        setContentView(root)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
