# AutoCheck currently does not need custom ProGuard/R8 rules.
