# Auto Check – Android App

Eine native Android-App im gewünschten Auto-Check-Look.

## Bereits umgesetzt

- Portrait-optimierte Android-Startseite.
- Bild 1 als App-Icon (`app_icon.png`).
- Auto-Check-Garagen-Szene als Hintergrund.
- Header mit Gear-Logo, `AUTO CHECK` und `VERLIERE NICHT DIE ÜBERSICHT`.
- `Created by D.M.` bleibt dezent im Hintergrund integriert.
- 6 echte, klickbare Buttons:
  - MEIN AUTO
  - REPARATUREN
  - WARTUNGEN
  - KOSTEN
  - STATISTIK
  - EINSTELLUNGEN
- Die 3 oberen Buttons fahren von rechts ein.
- Die 3 unteren Buttons fahren von links ein.
- Logo/Header fährt von oben ein.
- Alle Intro-Bewegungen laufen über 2,5 Sekunden.
- Buttons reagieren auf Touch und öffnen bereits ein eigenes Untermenü-Platzhalterfenster.
- Das Untermenü kann später pro Bereich erweitert werden.

## APK über GitHub bauen

1. Dieses Projekt in ein neues GitHub-Repository hochladen.
2. GitHub → **Actions** öffnen.
3. Den Workflow **Build Android APK** auswählen.
4. Nach dem erfolgreichen Lauf unter **Artifacts** `AutoCheck-debug-apk` herunterladen.
5. Die enthaltene `app-debug.apk` kann auf einem Android-Handy installiert werden.

Der Workflow installiert Java 17, Android SDK 35 und Gradle 8.9 automatisch.

## Mit Android Studio

Den kompletten Ordner `AutoCheck` als bestehendes Gradle-Projekt öffnen. Android Studio synchronisiert die Gradle-Konfiguration. Danach:

**Build → Build Bundle(s) / APK(s) → Build APK(s)**

## Nächster sinnvoller Ausbau

Die sechs Untermenüs können jetzt einzeln mit echten Funktionen gefüllt werden, z. B. Fahrzeugdaten, Reparaturhistorie, Wartungsintervalle, Kosten, Statistiken und Einstellungen.
